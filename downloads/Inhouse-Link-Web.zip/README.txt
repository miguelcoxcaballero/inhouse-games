inhouse link — web y servicio

Requiere Node.js22.12+. Ejecuta npm ci --omit=dev y npm start.
Para cargar .env: node --env-file=.env server/index.mjs
Consulta docs/deployment.md para HTTPS y STUN/TURN.
El ejecutable Windows se entrega por separado.
